# thumbulator
Cycle-accurate ARMv6-M simulator
